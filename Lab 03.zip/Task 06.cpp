#include<iostream>
using namespace std;

class Node
{
public:
	int data;
	Node *next;
};

class LinkedList
{
	Node *head;
public:
	LinkedList()
	{
		head = NULL;
	}
	void Insert_End(int value)
	{
		Node *newNode = new Node;
		newNode->data = value;
		newNode->next = NULL;
		if (head == NULL)
		{
			head = newNode;
		}
		else
		{
			Node *temp = head;
			while (temp->next != NULL)
			{
				temp = temp->next;
			}
			temp->next = newNode;
		}
	}
	void Display()
	{
		cout << "Data elements of a Singly LinkedList: ";
		Node *temp = head;
		while (temp != NULL)
		{
			cout << temp->data << " ";
			temp = temp->next;
		}
		cout << endl;
	}
};

int main()
{
	LinkedList obj;
	obj.Insert_End(10);
	obj.Insert_End(20);
	obj.Insert_End(30);
	obj.Insert_End(40);
	obj.Insert_End(50);
	obj.Display();


	return 0;
}