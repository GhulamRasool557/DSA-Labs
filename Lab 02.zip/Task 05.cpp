#include <iostream>
using namespace std;

void sortArray(int arr[], int size);
void findMostFrequent(int arr[], int size);

int main() 
{
	int size;
	cout << "Enter the number of elements: ";
	cin >> size;

	int *ptr= new int[size];
	cout << "Enter the elements: ";
	for (int i = 0; i < size; i++) 
	{
		cin >> ptr[i];
	}

	findMostFrequent(ptr, size);


	return 0;
}

void sortArray(int arr[], int size)
{
	for (int i = 0; i < size - 1; i++)
	{
		for (int j = i + 1; j < size; j++)
		{
			if (arr[i] > arr[j])
			{
				int temp = arr[i];
				arr[i] = arr[j];
				arr[j] = temp;
			}
		}
	}
}

void findMostFrequent(int arr[], int size)
{
	sortArray(arr, size);

	int maxFreq = 0, currentFreq = 1, mostFrequent = arr[0];

	for (int i = 1; i < size; i++)
	{
		if (arr[i] == arr[i - 1])
		{
			currentFreq++;
		}
		else
		{
			if (currentFreq > maxFreq)
			{
				maxFreq = currentFreq;
				mostFrequent = arr[i - 1];
			}
			currentFreq = 1;
		}
	}

	if (currentFreq > maxFreq)
	{
		maxFreq = currentFreq;
		mostFrequent = arr[size - 1];
	}

	cout << "Most Frequent Element: " << mostFrequent << endl;
	cout << "Frequency: " << maxFreq << endl;
}