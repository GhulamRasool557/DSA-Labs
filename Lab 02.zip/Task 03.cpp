#include<iostream>
using namespace std;

void SecLargest(int *ptr, int size);

int main()
{
	int size = 0;
	cout << "Enter the size of dynamic array: ";
	cin >> size;

	int *ptr = new int[size];

	SecLargest(ptr, size);


	return 0;
}
void SecLargest(int *ptr, int size)
{
	cout << "Enter the elements" << endl;
	for (int i = 0; i < size; i++)
	{
		cout << "index " << i << ": ";
		cin >> ptr[i];
	}

	int temp = 0;
	for (int i = 0; i < size; i++)
	{
		for (int j = 0; j < size - 1; j++)
		{
			if (ptr[j] > ptr[j + 1])
			{
				temp = ptr[j];
				ptr[j] = ptr[j + 1];
				ptr[j + 1] = temp;
			}
		}
	}

	cout << ptr[size - 2] << " is the 2nd greatest" << endl;
}