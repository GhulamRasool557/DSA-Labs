#include<iostream>
using namespace std;

int main()
{
	int arr[3][3] = { 0 };

	cout << "Enter the elements" << endl;
	for (int i = 0; i < 3; i++)
	{
		for (int j = 0; j < 3; j++)
		{
			cout << "index: " << i << " " << j << ": ";
			cin >> arr[i][j];
		}
	}

	int sum = 0;
	cout << "OUTPUT" << endl;
	for (int i = 0; i < 3; i++)
	{
		for (int j = 0; j < 3; j++)
		{
			sum += arr[i][j];
		}
	}
	cout << "Sum of the 3x3 matrix: " << sum << endl;


	return 0;
}