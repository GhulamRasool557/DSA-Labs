#include<iostream>
using namespace std;

void Rotate(int *ptr, int size);

int main()
{
	int size = 0;
	cout << "Enter the size of dynamic array: ";
	cin >> size;

	int *ptr = new int[size];

	cout << "Enter the elements" << endl;
	for (int i = 0; i < size; i++)
	{
		cout << "index " << i << ": ";
		cin >> ptr[i];
	}

	Rotate(ptr, size);

	return 0;
}
void Rotate(int *ptr, int size)
{
	for (int i = 0; i < 2; i++)
	{
		int temp = 0;

		temp = ptr[size - 1];

		for (int i = size - 2; i >= 0; i--)
		{
			ptr[i + 1] = ptr[i];
		}

		ptr[0] = temp;
	}

	for (int i = 0; i < size; i++)
	{
		cout << ptr[i] << " ";
	}
	cout << endl;

}