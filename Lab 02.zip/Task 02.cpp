#include<iostream>
using namespace std;

int main()
{
	int arr[3][3] = { 0 };
	int store[3] = { 0 };

	cout << "Enter the elements" << endl;
	for (int i = 0; i < 3; i++)
	{
		for (int j = 0; j < 3; j++)
		{
			cout << "index: " << i << " " << j << ": ";
			cin >> arr[i][j];
		}
	}

	cout << "OUTPUT" << endl;
	for (int i = 0; i < 3; i++)
	{
		if (arr[i][0] < arr[i][1])
		{
			if (arr[i][0] < arr[i][2])
			{
				store[i] = arr[i][0];
			}
			else
			{
				store[i] = arr[i][2];
			}
		}
		else
		{
			if (arr[i][1] < arr[i][2])
			{
				store[i] = arr[i][1];
			}
			else
				store[i] = arr[i][2];
		}
	}

	if (store[0] > store[1])
	{
		if (store[0] > store[2])
		{
			cout << store[0] << " is the Saddle" << endl;
		}
		else
		{
			cout << store[2] << " is the Saddle" << endl;
		}
	}
	else
	{
		if (store[1] > store[2])
		{
			cout << store[1] << " is the Saddle" << endl;
		}
		else
			cout << store[2] << " is the Saddle" << endl;
	}


	return 0;
}