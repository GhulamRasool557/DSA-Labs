#include <iostream>
using namespace std;

const int Max = 100;

template <typename T>
class AbstractStack 
{
public:
	virtual void push(T value) = 0;
	virtual T pop() = 0;
	virtual T top() const = 0;
	virtual bool isEmpty() const = 0;
	virtual bool isFull() const = 0;
	virtual void display() const = 0;
	virtual ~AbstractStack() {}
};

template <typename T>
class myStack : public AbstractStack<T> 
{
private:
	T* arr;
	T* minArr;
	int topIndex;
	int minTopIndex;
	int capacity;
public:
	myStack(int size = MAX) 
	{
		capacity = size;
		arr = new T[capacity];
		minArr = new T[capacity];
		topIndex = -1;
		minTopIndex = -1;
	}
	~myStack() 
	{
		delete[] arr;
		delete[] minArr;
	}
	void push(T value) override 
	{
		if (isFull()) cout << "Stack is full!" << endl;
		else {
			arr[++topIndex] = value;
			if (minTopIndex == -1 || value <= minArr[minTopIndex])
				minArr[++minTopIndex] = value;
		}
	}
	T pop() override 
	{
		if (isEmpty()) 
		{
			cout << "Stack is empty!" << endl;
			return T();
		}
		T popped = arr[topIndex--];
		if (popped == minArr[minTopIndex])
			minTopIndex--;
		return popped;
	}
	T top() const override 
	{
		if (isEmpty()) 
		{
			cout << "Stack is empty!" << endl;
			return T();
		}
		return arr[topIndex];
	}
	T getMin() const 
	{
		if (minTopIndex == -1) 
		{
			cout << "Stack is empty!" << endl;
			return T();
		}
		return minArr[minTopIndex];
	}
	bool isEmpty() const override 
	{
		return topIndex == -1;
	}
	bool isFull() const override 
	{
		return topIndex == capacity - 1;
	}
	void display() const override 
	{
		if (isEmpty()) cout << "Stack is empty." << endl;
		else {
			for (int i = topIndex; i >= 0; i--)
				cout << arr[i] << " ";
			cout << endl;
		}
	}
};

int main() 
{
	myStack<int> stack(10);
	int choice, value;
	do {
		cout << endl;
		cout << "1. Push" << endl;
		cout << "2. Pop" << endl;
		cout << "3. Top" << endl;
		cout << "4. isEmpty" << endl;
		cout << "5. isFull" << endl;
		cout << "6. Display" << endl;
		cout << "7. Show Min" << endl;
		cout << "8. Exit" << endl;
		cout << "Choice: ";
		cin >> choice;
		switch (choice) 
		{
		case 1: cout << "Enter value: "; cin >> value; stack.push(value); break;
		case 2: cout << "Popped: " << stack.pop() << endl; break;
		case 3: cout << "Top: " << stack.top() << endl; break;
		case 4:
			if (stack.isEmpty())
				cout << "Yes" << endl;
			else
				cout << "No" << endl;
			break;
		case 5:
			if (stack.isFull())
				cout << "Yes" << endl;
			else
				cout << "No" << endl;
			break;
		case 6: stack.display(); break;
		case 7: cout << "Minimum: " << stack.getMin() << endl; break;
		}
	} while (choice != 8);

	return 0;
}