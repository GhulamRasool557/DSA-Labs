#include <iostream>
using namespace std;

const int Max = 100;

template <typename T>
class AbstractStack 
{
public:
	virtual void push(T value) = 0;
	virtual T pop() = 0;
	virtual T top() const = 0;
	virtual bool isEmpty() const = 0;
	virtual bool isFull() const = 0;
	virtual void display() const = 0;
	virtual ~AbstractStack() {}
};

template <typename T>
class myStack : public AbstractStack<T> 
{
private:
	T* arr;
	int topIndex;
	int capacity;

public:
	myStack(int size = MAX) 
	{
		capacity = size;
		arr = new T[capacity];
		topIndex = -1;
	}

	~myStack() {
		delete[] arr;
	}

	void push(T value) override 
	{
		if (isFull()) 
		{
			cout << "Stack is full" << endl;
		}
		else {
			arr[++topIndex] = value;
		}
	}

	T pop() override 
	{
		if (isEmpty()) 
		{
			cout << "Stack is empty" << endl;
			return T();
		}
		return arr[topIndex--];
	}

	T top() const override 
	{
		if (isEmpty()) 
		{
			cout << "Stack is empty" << endl;
			return T();
		}
		return arr[topIndex];
	}

	bool isEmpty() const override 
	{
		return topIndex == -1;
	}

	bool isFull() const override 
	{
		return topIndex == capacity - 1;
	}

	void display() const override 
	{
		if (isEmpty()) 
		{
			cout << "Stack is empty." << endl;
		}
		else {
			cout << "Stack items (top to bottom):" << endl;
			for (int i = topIndex; i >= 0; i--) 
			{
				cout << arr[i] << " ";
			}
			cout << endl;
		}
	}
};

int main() 
{
	myStack<int> stack(5);
	int choice, value;

	do 
	{
		cout << " Stack Menu " << endl;
		cout << "1. Push (Add item)" << endl;
		cout << "2. Pop (Remove top item)" << endl;
		cout << "3. Top (View top item)" << endl;
		cout << "4. Check if Empty" << endl;
		cout << "5. Check if Full" << endl;
		cout << "6. Display Stack" << endl;
		cout << "7. Exit" << endl;
		cout << "Enter your choice: ";
		cin >> choice;

		switch (choice) 
		{
		case 1:
			cout << "Enter value to push: ";
			cin >> value;
			stack.push(value);
			break;
		case 2:
			cout << "Popped value: " << stack.pop() << endl;
			break;
		case 3:
			cout << "Top item is: " << stack.top() << endl;
			break;
		case 4:
			if (stack.isEmpty()) 
			{
				cout << "Yes, the stack is empty." << endl;
			}
			else {
				cout << "No, the stack is not empty." << endl;
			}
			break;
		case 5:
			if (stack.isFull()) 
			{
				cout << "Yes, the stack is full." << endl;
			}
			else 
			{
				cout << "No, the stack is not full." << endl;
			}
			break;
		case 6:
			stack.display();
			break;
		case 7:
			cout << "Exiting program." << endl;
			break;
		default:
			cout << "Invalid option." << endl;
		}
	} while (choice != 7);

	return 0;
}
