#include <iostream>
using namespace std;

const int maxHistory = 100;
const int maxLength = 1000;

class TextEditor 
{
private:
	char text[maxLength];
	int textLength;               

	char undoHistory[maxHistory][maxLength];
	int undoLengths[maxHistory];
	int undoTop;

	char redoHistory[maxHistory][maxLength];
	int redoLengths[maxHistory];
	int redoTop;

public:
	TextEditor() 
	{
		textLength = 0;
		undoTop = -1;
		redoTop = -1;
	}

	void typeText(const char* newText) 
	{
		if (undoTop < maxHistory - 1) 
		{
			undoTop++;
			for (int i = 0; i < textLength; i++) 
			{
				undoHistory[undoTop][i] = text[i];
			}
			undoLengths[undoTop] = textLength;
		}

		int i = 0;
		while (newText[i] != '\0' && textLength < maxLength)
		{
			text[textLength++] = newText[i];
			i++;
		}

		redoTop = -1; 
		cout << "Text added." << endl;
	}

	void deleteText(int count) 
	{
		if (count > textLength) 
		{
			count = textLength;
		}

		if (undoTop < maxHistory - 1) 
		{
			undoTop++;
			for (int i = 0; i < textLength; i++) 
			{
				undoHistory[undoTop][i] = text[i];
			}
			undoLengths[undoTop] = textLength;
		}

		textLength -= count;
		redoTop = -1;
		cout << count << " characters removed." << endl;
	}

	// Reverts to the previous version
	void undo() {
		if (undoTop >= 0) 
		{
			if (redoTop < maxHistory - 1) 
			{
				redoTop++;
				for (int i = 0; i < textLength; i++) 
				{
					redoHistory[redoTop][i] = text[i];
				}
				redoLengths[redoTop] = textLength;
			}

			textLength = undoLengths[undoTop];
			for (int i = 0; i < textLength; i++) 
			{
				text[i] = undoHistory[undoTop][i];
			}
			undoTop--;
			cout << "Undo completed." << endl;
		}
		else 
		{
			cout << "No more actions to undo." << endl;
		}
	}

	void redo() 
	{
		if (redoTop >= 0) 
		{
			if (undoTop < maxHistory - 1) 
			{
				undoTop++;
				for (int i = 0; i < textLength; i++) 
				{
					undoHistory[undoTop][i] = text[i];
				}
				undoLengths[undoTop] = textLength;
			}

			textLength = redoLengths[redoTop];
			for (int i = 0; i < textLength; i++) 
			{
				text[i] = redoHistory[redoTop][i];
			}
			redoTop--;
			cout << "Redo completed." << endl;
		}
		else 
		{
			cout << "No actions to redo." << endl;
		}
	}

	void displayText() const 
	{
		cout << "Current Text: ";
		for (int i = 0; i < textLength; i++) 
		{
			cout << text[i];
		}
//		cout << "\"" << endl;
		cout << endl;
	}
};

int main() 
{
	TextEditor editor;
	int choice;
	char inputText[maxLength];
	int deleteCount;

	do 
	{
		cout << endl;
		cout << "	Simple Text Editor	" << endl;
		cout << "1. Type Text" << endl;
		cout << "2. Delete Text" << endl;
		cout << "3. Undo Last Action" << endl;
		cout << "4. Redo Last Action" << endl;
		cout << "5. Show Current Text" << endl;
		cout << "6. Exit" << endl;
		cout << "Enter your choice (1-6): ";
		cin >> choice;
		cin.ignore();

		switch (choice) 
		{
		case 1:
			cout << "Enter text to type: ";
			cin.getline(inputText, maxLength);
			editor.typeText(inputText);
			break;
		case 2:
			cout << "Enter number of characters to delete: ";
			cin >> deleteCount;
			editor.deleteText(deleteCount);
			break;
		case 3:
			editor.undo();
			break;
		case 4:
			editor.redo();
			break;
		case 5:
			editor.displayText();
			break;
		case 6:
			cout << "Good Bye..." << endl;
			break;
		default:
			cout << "Invalid option. Please try again." << endl;
		}
	} while (choice != 6);

	return 0;
}