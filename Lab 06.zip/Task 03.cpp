#include <iostream>
#include <string>
using namespace std;

const int maxCars = 8;

class CarStack 
{
private:
	string cars[maxCars];
	int top;
public:
	CarStack() 
	{
		top = -1;
	}

	bool isFull() const 
	{
		return top == maxCars - 1; 
	}
	bool isEmpty() const 
	{
		return top == -1; 
	}

	void push(string carNumber) 
	{
		if (isFull()) cout << "Parking lot is full!" << endl;
		else cars[++top] = carNumber;
	}

	string pop() 
	{
		if (isEmpty()) return "";
		return cars[top--];
	}

	string peek() const 
	{
		if (isEmpty()) return "";
		return cars[top];
	}

	int size() const 
	{
		return top + 1; 
	}

	bool search(string carNumber) const 
	{
		for (int i = 0; i <= top; ++i) 
		{
			if (cars[i] == carNumber) return true;
		}
		return false;
	}

	void display() const 
	{
		if (isEmpty()) cout << "No cars parked." << endl;
		else
		{
			cout << "Cars in parking lot (top to bottom):" << endl;
			for (int i = top; i >= 0; --i) 
			{
				cout << cars[i] << endl;
			}
		}
	}
};

int main() 
{
	CarStack parkingLot, tempStack;
	int choice;
	string carNumber;

	do {
		cout << endl;
		cout << "	Parking Lot Menu	" << endl;
		cout << "1. Park a car" << endl;
		cout << "2. Remove a car" << endl;
		cout << "3. View parked cars" << endl;
		cout << "4. Total parked cars" << endl;
		cout << "5. Search car" << endl;
		cout << "6. Exit" << endl;
		cout << "Enter choice: ";
		cin >> choice;

		if (choice == 1)
		{
			cout << "Enter car number: ";
			cin >> carNumber;
			parkingLot.push(carNumber);
		}
		else if (choice == 2) 
		{
			cout << "Enter car number to remove: ";
			cin >> carNumber;

			if (!parkingLot.search(carNumber)) 
			{
				cout << "Car not found." << endl;
			}
			else 
			{
				while (parkingLot.peek() != carNumber) 
				{
					tempStack.push(parkingLot.pop());
				}
				parkingLot.pop();
				cout << "Car " << carNumber << " removed." << endl;
				while (!tempStack.isEmpty()) 
				{
					parkingLot.push(tempStack.pop());
				}
			}
		}
		else if (choice == 3) 
		{
			parkingLot.display();
		}
		else if (choice == 4) 
		{
			cout << "Total cars parked: " << parkingLot.size() << endl;
		}
		else if (choice == 5) 
		{
			cout << "Enter car number to search: ";
			cin >> carNumber;
			if (parkingLot.search(carNumber))
				cout << "Car is in the parking lot." << endl;
			else
				cout << "Car not found." << endl;
		}
		else if (choice == 6) 
		{
			cout << "Exiting..." << endl;
		}
		else 
		{
			cout << "Invalid choice!" << endl;
		}
	} while (choice != 6);

	return 0;
}
